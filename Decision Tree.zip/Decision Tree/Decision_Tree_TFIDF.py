from time import time
import pandas as pd
import os
from nltk.corpus import stopwords
import string
import re
from nltk.stem.wordnet import WordNetLemmatizer
from nltk.tokenize import word_tokenize
from nltk.stem.snowball import SnowballStemmer
from collections import Counter
from sklearn import tree
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn import metrics
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import roc_auc_score
from sklearn.metrics import accuracy_score


import math


#df_master = pd.read_csv("removedsup.csv", encoding='latin-1', index_col = 0)
#imdb_train = df_master[["review", "label"]][df_master.type.isin(['train'])].reset_index(drop=True)


#imdb_test = df_master[["review", "label"]][df_master.type.isin(['validation'])].reset_index(drop=True)
#imdb_test['review'] = rem_punc(imdb_train['review'])
#imdb_test['review'] = rem_sw(imdb_train['review'])
#imdb_test['review'] = lemma(imdb_train['review'])
#imdb_test['review'] = stemma(imdb_train['review'])



f = open('output_parameter.txt','a')
fi = open('output_parameter_f1.txt','a');
f1_score=list()
score_list = list()

for i in range(1,6):
    fileString = "imdb_master_"+str(i)+".csv"
    df_master = pd.read_csv(fileString, encoding='latin-1', index_col = 0)
    imdb_full = df_master[["review", "label"]][df_master.type.isin(['train'])].reset_index(drop=True)
    print("RUN: ",i)
    print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
    imdb_full = df_master[["review", "label"]][df_master.type.isin(['train'])].sample(frac=1).reset_index(drop=True)

    train_rev = pd.Series(imdb_full['review'][:12500])
    train_lab = pd.Series(imdb_full['label'][:12500])
    test_rev = pd.Series(imdb_full['review'][12500:])
    test_lab = pd.Series(imdb_full['label'][12500:])
    
    vect_algo = TfidfVectorizer(stop_words='english', analyzer='word')
    vect_algo.fit(train_rev)
    Xf_train = vect_algo.transform(train_rev)
    Xf_test = vect_algo.transform(test_rev)

    le = LabelEncoder()
    yf_train = le.fit_transform(train_lab)
    yf_test = le.fit_transform(test_lab)

    clf = tree.DecisionTreeClassifier(max_depth=7)
    clf.fit(Xf_train, yf_train)

# predict the outcome for testing data
    predictions = clf.predict(Xf_test)
# Score calculation
    preds = clf.predict_proba(Xf_test)[:, 1]
    score = roc_auc_score(yf_test,preds)
    score_list.append(score)
    
    

# check the accuracy of the model
#accuracy = accuracy_score(yf_test, predictions)


    j = 0
    correct = 0
    incorrect =0
    true_pos=0
    true_neg=0
    false_pos=0
    false_neg=0

    for i in yf_test:
        if i==predictions[j] and i==1:
            correct+=1
            true_pos+=1
        elif i==predictions[j] and i==0:
            correct+=1
            true_neg+=1
        elif i!=predictions[j] and predictions[j]==1:
            incorrect+=1
            false_pos+=1
        else:
            incorrect+=1
            false_neg+=1
        j+=1

    print("The number of right predictions is: ",correct)
    print("The number of wrong predictions is: ",incorrect)
    print("True positive: ", true_pos)
    print("True negative: ", true_neg)
    print("False positive: ", false_pos)
    print("False negative: ", false_neg)
    accuracy = correct/float(correct+incorrect)
    precision = true_pos/float(true_pos+false_pos)
    recall = true_pos/float(true_pos+false_neg)
    f1 = (2 * precision * recall) / float(precision + recall)
    print('Accuracy: ',round(accuracy,4))
    print("Precision: ", round(precision,4))
    print("Recall: ",round(recall,4))
    print("F1 score: ",round(f1,4))
    f1_score.append(f1)

    temp = train_rev
    train_rev = test_rev
    test_rev = temp

    temp = train_lab
    train_lab = test_lab
    test_lab = temp
    
    print("Swapping train and validation")
    print("---------------------------------------------------------------------------------")
    vect_algo = TfidfVectorizer(stop_words='english', analyzer='word')
    vect_algo.fit(train_rev)
    Xf_train = vect_algo.transform(train_rev)
    Xf_test = vect_algo.transform(test_rev)

    le = LabelEncoder()
    yf_train = le.fit_transform(train_lab)
    yf_test = le.fit_transform(test_lab)

    clf = tree.DecisionTreeClassifier(max_depth=7)
    clf.fit(Xf_train, yf_train)

# predict the outcome for testing data
    predictions = clf.predict(Xf_test)
# Score calculation
    preds = clf.predict_proba(Xf_test)[:, 1]
    score = roc_auc_score(yf_test,preds)
    score_list.append(score)
    

# check the accuracy of the model
#accuracy = accuracy_score(yf_test, predictions)


    j = 0
    correct = 0
    incorrect =0
    true_pos=0
    true_neg=0
    false_pos=0
    false_neg=0

    for i in yf_test:
        if i==predictions[j] and i==1:
            correct+=1
            true_pos+=1
        elif i==predictions[j] and i==0:
            correct+=1
            true_neg+=1
        elif i!=predictions[j] and predictions[j]==1:
            incorrect+=1
            false_pos+=1
        else:
            incorrect+=1
            false_neg+=1
        j+=1

    print("The number of right predictions is: ",correct)
    print("The number of wrong predictions is: ",incorrect)
    print("True positive: ", true_pos)
    print("True negative: ", true_neg)
    print("False positive: ", false_pos)
    print("False negative: ", false_neg)
    accuracy = correct/float(correct+incorrect)
    precision = true_pos/float(true_pos+false_pos)
    recall = true_pos/float(true_pos+false_neg)
    f1 = (2 * precision * recall) / float(precision + recall)
    print('Accuracy: ',round(accuracy,4))
    print("Precision: ", round(precision,4))
    print("Recall: ",round(recall,4))
    print("F1 score: ",round(f1,4))
    f1_score.append(f1)
    print("DONE______________________________________________________________________________________")


f.write("Decision Tree -k=7 - TFIDF: ")
str1 = ' '.join(map(str,score_list))
f.write(str1)
f.write("\n")
f.close()

fi.write("Decision Tree- k=7 - TFIDF: ")
str2= ' '.join(map(str,f1_score))
fi.write(str2)
fi.write("\n");
fi.close()
    
